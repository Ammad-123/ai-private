from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional
import os
from typing import Annotated, Sequence, TypedDict
from operator import add as add_messages

from langgraph.graph import StateGraph, END
from langchain_core.messages import BaseMessage, SystemMessage, HumanMessage, ToolMessage, AIMessage
from langchain_core.tools import tool
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_chroma import Chroma
from openai import OpenAI

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:8000"], 
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
# Initialize vector store (assuming it's already created)
embeddings = HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")
vectorstore = Chroma(persist_directory="./chroma_ecommerce_db", embedding_function=embeddings)
# retriever = vectorstore.as_retriever(search_kwargs={"k": 3})
retriever = vectorstore.as_retriever(
    search_type="similarity",  # or "mmr" for Max Marginal Relevance
    search_kwargs={"k": 3}
)

# === Tool Definition ===
@tool
def retriever_tool(query: str) -> str:
    """
    Searches for information in the Ecommerce Sales and Policies 2024 document.
    Returns relevant excerpts from the document.
    """
    docs = retriever.invoke(query)
    if not docs:
        return "No relevant information found in the document."
    return "\n\n".join(f"Document Excerpt {i+1}:\n{doc.page_content}" for i, doc in enumerate(docs))

tools = [retriever_tool]
tools_dict = {tool.name: tool for tool in tools}

# === Grok LLM Setup ===
GROK_API_KEY = "xai-2y1x3fAgrvqDDTer1ADExs6Mgx6j6OepMly5i41CxMxGIKyxix442MWVCkfyukbVHpzGh7AolqIIpBN4"  # Replace with your actual key
grok_client = OpenAI(
    api_key=GROK_API_KEY,
    base_url="https://api.x.ai/v1"
)

# === State Definition ===
class AgentState(TypedDict):
    messages: Annotated[Sequence[BaseMessage], add_messages]

# === System Prompt ===
system_prompt = """
You are an expert AI assistant for the Ecommerce Sales and Policies 2024 document.
Your responses must be accurate and based ONLY on the provided document content.

For sales data requests:
- Calculate totals when asked for quarterly data
- Identify trends (increasing/decreasing) when relevant
- Format numerical values consistently (e.g., $24,000)
- Include refund information when relevant

For policy questions:
- Provide exact details from the document
- Clarify any conditions or limitations

Structure your responses clearly with headings when appropriate.
Always cite your source as (Source: Ecommerce Sales and Policies 2024).
"""

# === LLM Call using Grok ===
def call_llm(state: AgentState) -> AgentState:
    messages = [SystemMessage(content=system_prompt)] + list(state["messages"])

    grok_messages = []
    for msg in messages:
        if isinstance(msg, HumanMessage):
            grok_messages.append({"role": "user", "content": msg.content})
        elif isinstance(msg, SystemMessage):
            grok_messages.append({"role": "system", "content": msg.content})
        elif isinstance(msg, AIMessage):
            grok_messages.append({"role": "assistant", "content": msg.content})
        elif isinstance(msg, ToolMessage):
            grok_messages.append({
                "role": "tool",
                "tool_call_id": msg.tool_call_id,
                "content": msg.content,
            })

    tool_schemas = [{
        "type": "function",
        "function": {
            "name": tool.name,
            "description": tool.description,
            "parameters": {
                "type": "object",
                "properties": {"query": {"type": "string"}},
                "required": ["query"]
            }
        }
    } for tool in tools]

    response = grok_client.chat.completions.create(
        model="grok-3-beta",
        messages=grok_messages,
        tools=tool_schemas,
        tool_choice="auto"
    )

    grok_reply = response.choices[0].message

    return {
        "messages": [AIMessage(
            content=grok_reply.content or "",
            additional_kwargs={"tool_calls": grok_reply.tool_calls} if hasattr(grok_reply, "tool_calls") else {}
        )]
    }

# === Tool Call Execution ===
def take_action(state: AgentState) -> AgentState:
    tool_calls = state["messages"][-1].tool_calls
    results = []

    for t in tool_calls:
        tool_fn = tools_dict.get(t['name'])
        if not tool_fn:
            result = "Invalid tool call."
        else:
            result = tool_fn.invoke(t['args']['query'])

        results.append(ToolMessage(
            tool_call_id=t['id'],
            name=t['name'],
            content=str(result)
        ))

    return {
        "messages": state["messages"] + results
    }

# === Decision Function ===
def should_continue(state: AgentState):
    return hasattr(state["messages"][-1], "tool_calls") and bool(state["messages"][-1].tool_calls)

# === LangGraph Construction ===
graph = StateGraph(AgentState)
graph.add_node("llm", call_llm)
graph.add_node("retriever_agent", take_action)
graph.set_entry_point("llm")

graph.add_conditional_edges("llm", should_continue, {True: "retriever_agent", False: END})
graph.add_edge("retriever_agent", "llm")

rag_agent = graph.compile()

# === API Models ===
class QueryRequest(BaseModel):
    question: str
    chat_history: Optional[List[dict]] = None

class QueryResponse(BaseModel):
    answer: str
    sources: List[str]

# === API Endpoints ===
@app.post("/query", response_model=QueryResponse)
async def query_document(request: QueryRequest):
    try:
        # Convert chat history to messages (only user messages for context)
        messages = []
        if request.chat_history:
            for msg in request.chat_history:
                if msg["role"] == "user":
                    messages.append(HumanMessage(content=msg["content"]))
                # we skip assistant messages to avoid duplication

        # Add the latest user question
        messages.append(HumanMessage(content=request.question))
        
        inputs = {"messages": messages}
        result = rag_agent.invoke(inputs)
        
        # Extract sources from tool messages if any
        sources = []
        for msg in result["messages"]:
            if isinstance(msg, ToolMessage):
                sources.append(msg.content)
        
        return QueryResponse(
            answer=result["messages"][-1].content,
            sources=sources
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/health")
async def health_check():
    return {"status": "healthy"}


if __name__ == "__main__":
    import uvicorn
    import signal
    import sys
    from fastapi import FastAPI

    
    # Add shutdown handler
    def shutdown_handler(signal, frame):
        print("\nShutting down server...")
        # Add any cleanup code here (e.g., vectorstore persistence)
        sys.exit(0)
    
    # Register signal handlers
    signal.signal(signal.SIGINT, shutdown_handler)
    signal.signal(signal.SIGTERM, shutdown_handler)
    
    # Configure Uvicorn to handle shutdown properly
    uvicorn.run(
        app,
        host="0.0.0.0",
        port=8000,
        workers=1,  # Use 1 worker for easier signal handling
        timeout_keep_alive=30,  # Helps with cleanup
        log_config=None,  # Disable uvicorn's default logging if needed
    )