import streamlit as st
import requests
from typing import List, Dict

BACKEND_URL = "http://localhost:8000"

if "chat_history" not in st.session_state:
    st.session_state.chat_history = []

st.set_page_config(page_title="Ecommerce Document Assistant", page_icon="📄")
st.title("📄 Ecommerce Document Assistant")
st.caption("Ask questions about the Ecommerce Sales and Policies 2024 document")

with st.sidebar:
    st.header("Settings")
    show_sources = st.checkbox("Show document sources", value=True)
    st.markdown("---")
    st.markdown("**About**")
    st.markdown("This assistant uses RAG to answer questions from the Ecommerce Sales and Policies 2024 document.")

for message in st.session_state.chat_history:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])
        if message["role"] == "assistant" and show_sources and "sources" in message:
            with st.expander("Document Sources"):
                for source in message["sources"]:
                    st.text(source)

user_query = st.chat_input("Ask a question about the document...")

if user_query:
    st.session_state.chat_history.append({"role": "user", "content": user_query})
    with st.chat_message("user"):
        st.markdown(user_query)
    
    payload = {"question": user_query, "chat_history": []}
    
    with st.spinner("Searching the document..."):
        try:
            response = requests.post(f"{BACKEND_URL}/query", json=payload)
            response.raise_for_status()
            result = response.json()

            assistant_message = {
                "role": "assistant",
                "content": result["answer"],
                "sources": result["sources"],
            }
            st.session_state.chat_history.append(assistant_message)
            
            with st.chat_message("assistant"):
                st.markdown(result["answer"])
                if show_sources and result["sources"]:
                    with st.expander("Document Sources"):
                        for source in result["sources"]:
                            st.text(source)
        
        except requests.exceptions.RequestException as e:
            st.error(f"Error communicating with the backend: {str(e)}")
        except Exception as e:
            st.error(f"An error occurred: {str(e)}")

if st.session_state.chat_history:
    if st.button("Clear Chat"):
        st.session_state.chat_history = []
        st.rerun()
